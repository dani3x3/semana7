package com.example.jose_cavero_semana_7

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class FeriadoAdapter(private var feriados: MutableList<Feriado>) : RecyclerView.Adapter<FeriadoAdapter.FeriadoViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FeriadoViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.item_feriado, parent, false)
        return FeriadoViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: FeriadoViewHolder, position: Int) {
        val feriado = feriados[position]
        holder.bind(feriado)
    }

    override fun getItemCount() = feriados.size

    fun actualizarFeriados(nuevosFeriados: List<Feriado>) {
        feriados.clear()
        feriados.addAll(nuevosFeriados)
        notifyDataSetChanged()
    }

    inner class FeriadoViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val textViewNombreFeriado: TextView = itemView.findViewById(R.id.textViewNombreFeriado)
        private val textViewFechaFeriado: TextView = itemView.findViewById(R.id.textViewFechaFeriado)
        private val textViewTipoFeriado: TextView = itemView.findViewById(R.id.textViewTipoFeriado)

        fun bind(feriado: Feriado) {
            textViewNombreFeriado.text = feriado.nombre
            textViewFechaFeriado.text = feriado.fecha
            textViewTipoFeriado.text = feriado.tipo
        }
    }
}

