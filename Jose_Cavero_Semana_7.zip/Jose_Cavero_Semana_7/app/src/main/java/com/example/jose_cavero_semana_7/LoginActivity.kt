package com.example.jose_cavero_semana_7

import android.content.Intent
import android.database.Cursor
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {

    private lateinit var dbHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        dbHelper = DatabaseHelper(this)

        val emailEditText: EditText = findViewById(R.id.editTextTextEmailAddress)
        val passwordEditText: EditText = findViewById(R.id.editTextTextPassword)
        val loginButton: Button = findViewById(R.id.buttonlogin)
        val registerButton: Button = findViewById(R.id.buttoncrear)

        // Manejar el clic del botón de inicio de sesión
        loginButton.setOnClickListener {
            val email = emailEditText.text.toString()
            val password = passwordEditText.text.toString()

            // Verificar si el correo y la contraseña son válidos
            if (isValidCredentials(email, password)) {
                // Si las credenciales son válidas, iniciar sesión exitosamente
                Toast.makeText(this@LoginActivity, "Inicio de sesión exitoso", Toast.LENGTH_SHORT).show()

                // Iniciar la actividad AgendaActivity
                val intent = Intent(this@LoginActivity, AgendaActivity::class.java)
                startActivity(intent)

                // Finalizar la actividad actual
                finish()
            } else {
                // Mostrar un mensaje de error si las credenciales no son válidas
                Toast.makeText(this@LoginActivity, "Correo o contraseña incorrectos", Toast.LENGTH_SHORT).show()
            }
        }

        // Manejar el clic del botón de registro
        registerButton.setOnClickListener {
            // Abrir la actividad de registro
            val intent = Intent(this@LoginActivity, RegistroActivity::class.java)
            startActivity(intent)
        }
    }

    // validar las credenciales en la base de datos
    private fun isValidCredentials(email: String, password: String): Boolean {
        val db = dbHelper.readableDatabase

        val projection = arrayOf(
            DatabaseContract.UserEntry.COLUMN_NAME_EMAIL,
            DatabaseContract.UserEntry.COLUMN_NAME_PASSWORD
        )
        val selection = "${DatabaseContract.UserEntry.COLUMN_NAME_EMAIL} = ? AND ${DatabaseContract.UserEntry.COLUMN_NAME_PASSWORD} = ?"
        val selectionArgs = arrayOf(email, password)

        val cursor: Cursor = db.query(
            DatabaseContract.UserEntry.TABLE_NAME,
            projection,
            selection,
            selectionArgs,
            null,
            null,
            null
        )

        val isValid = cursor.count > 0

        cursor.close()
        db.close()

        return isValid

        SessionManager.setLoginStatus(this, true)
    }
}
