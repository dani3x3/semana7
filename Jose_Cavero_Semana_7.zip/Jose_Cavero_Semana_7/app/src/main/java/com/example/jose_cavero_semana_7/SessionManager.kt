package com.example.jose_cavero_semana_7

import android.content.Context
import android.content.SharedPreferences

object SessionManager {
    private const val PREF_NAME = "LoginPrefs"
    private const val KEY_IS_LOGGED_IN = "isLoggedIn"

    fun setLoginStatus(context: Context, isLoggedIn: Boolean) {
        val editor: SharedPreferences.Editor = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE).edit()
        editor.putBoolean(KEY_IS_LOGGED_IN, isLoggedIn)
        editor.apply()
    }

    fun isLoggedIn(context: Context): Boolean {
        val sharedPreferences: SharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        return sharedPreferences.getBoolean(KEY_IS_LOGGED_IN, false)
    }
}
