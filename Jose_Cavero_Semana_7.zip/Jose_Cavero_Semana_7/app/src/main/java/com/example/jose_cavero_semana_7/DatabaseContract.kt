package com.example.jose_cavero_semana_7

import android.provider.BaseColumns

object DatabaseContract {
    // Definir el esquema de la tabla de usuarios
    class UserEntry : BaseColumns {
        companion object {
            const val TABLE_NAME = "users"
            const val COLUMN_NAME_ID = "id"
            const val COLUMN_NAME_EMAIL = "email"
            const val COLUMN_NAME_PASSWORD = "password"
            const val COLUMN_NAME_NOMBRE_USUARIO = "nombreUsuario" // Nuevo campo para el nombre de usuario

        }
    }
}
