package com.example.jose_cavero_semana_7

import android.content.ContentValues
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class RegistroActivity : AppCompatActivity() {

    private lateinit var dbHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registro)

        dbHelper = DatabaseHelper(this)

        val emailEditText: EditText = findViewById(R.id.editTextTextEmailAddress2)
        val passwordEditText: EditText = findViewById(R.id.editTextTextPassword2)
        val nombreUsuarioEditText: EditText = findViewById(R.id.editTextNombreUsuario) // Nuevo campo de nombre de usuario
        val registerButton: Button = findViewById(R.id.enviar)


        registerButton.setOnClickListener {
            val email = emailEditText.text.toString()
            val password = passwordEditText.text.toString()
            val nombreUsuario = nombreUsuarioEditText.text.toString() // Obtener el nombre de usuario ingresado


            // Verificar si el correo y la contraseña no están vacíos
            if (email.isNotEmpty() && password.isNotEmpty()) {
                // Insertar los datos en la base de datos
                insertUserData(email, password, nombreUsuario)
                // Mostrar un mensaje de registro exitoso
                Toast.makeText(this@RegistroActivity, "Registro exitoso", Toast.LENGTH_SHORT).show()
                // Fin de la actividad de registro
                finish()
            } else {
                // Mostrar un mensaje de error si el correo o la contraseña están vacíos
                Toast.makeText(this@RegistroActivity, "Por favor, complete todos los campos", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Método para insertar los datos del usuario en la base de datos
    private fun insertUserData(email: String, password: String, nombreUsuario: String) {
        val db = dbHelper.writableDatabase

        val values = ContentValues().apply {
            put(DatabaseContract.UserEntry.COLUMN_NAME_EMAIL, email)
            put(DatabaseContract.UserEntry.COLUMN_NAME_PASSWORD, password)
            put(DatabaseContract.UserEntry.COLUMN_NAME_NOMBRE_USUARIO, nombreUsuario) // Insertar el nombre de usuario

        }

        val newRowId = db.insert(DatabaseContract.UserEntry.TABLE_NAME, null, values)

        db.close()
    }
}
