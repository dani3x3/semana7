package com.example.jose_cavero_semana_7

data class Feriado(
    val fecha: String,
    val nombre: String,
    val tipo: String
)
