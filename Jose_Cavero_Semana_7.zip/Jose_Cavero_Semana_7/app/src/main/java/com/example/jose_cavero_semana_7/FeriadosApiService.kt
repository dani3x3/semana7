package com.example.jose_cavero_semana_7

import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

class FeriadosApiService {

    fun obtenerFeriados(year: Int) {
        val url = URL("https://apis.digital.gob.cl/fl/feriados/$year")
        val conexion = url.openConnection() as HttpURLConnection

        try {
            conexion.requestMethod = "GET"

            val respuestaCodigo = conexion.responseCode
            if (respuestaCodigo == HttpURLConnection.HTTP_OK) {
                val respuestaStream = BufferedReader(InputStreamReader(conexion.inputStream))
                val respuesta = StringBuilder()
                var linea: String?

                while (respuestaStream.readLine().also { linea = it } != null) {
                    respuesta.append(linea)
                }

                respuestaStream.close()

                // Procesar la respuesta JSON
                val jsonArray = JSONArray(respuesta.toString())
                for (i in 0 until jsonArray.length()) {
                    val jsonObject = jsonArray.getJSONObject(i)
                    val fecha = jsonObject.getString("fecha")
                    val nombre = jsonObject.getString("nombre")
                    val tipo = jsonObject.getString("tipo")


                }
            } else {
                Log.e("FeriadosApiService", "Error en la conexión: $respuestaCodigo")
            }
        } catch (e: Exception) {
            Log.e("FeriadosApiService", "Excepción durante la solicitud: ${e.message}")
        } finally {
            conexion.disconnect()
        }
    }
}
