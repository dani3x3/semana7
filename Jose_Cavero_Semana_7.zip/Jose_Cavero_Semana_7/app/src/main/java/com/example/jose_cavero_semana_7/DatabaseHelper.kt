package com.example.jose_cavero_semana_7

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_VERSION = 1
        private const val DATABASE_NAME = "User.db"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val SQL_CREATE_ENTRIES = "CREATE TABLE ${DatabaseContract.UserEntry.TABLE_NAME} (" +
                "${DatabaseContract.UserEntry.COLUMN_NAME_ID} INTEGER PRIMARY KEY," +
                "${DatabaseContract.UserEntry.COLUMN_NAME_EMAIL} TEXT," +
                "${DatabaseContract.UserEntry.COLUMN_NAME_PASSWORD} TEXT," +
                "${DatabaseContract.UserEntry.COLUMN_NAME_NOMBRE_USUARIO} TEXT)" // Agregar columna para nombre de usuario

        db.execSQL(SQL_CREATE_ENTRIES)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS ${DatabaseContract.UserEntry.TABLE_NAME}")
        onCreate(db)
    }

    // Método para obtener el nombre de usuario de la base de datos
    fun obtenerNombreUsuario(): String {
        val db = this.readableDatabase
        var nombreUsuario = ""

        val cursor = db.query(
            DatabaseContract.UserEntry.TABLE_NAME,  // The table to query
            arrayOf(DatabaseContract.UserEntry.COLUMN_NAME_NOMBRE_USUARIO),  // The array of columns to return (pass null to get all)
            null,  // The columns for the WHERE clause
            null,  // The values for the WHERE clause
            null,  // don't group the rows
            null,  // don't filter by row groups
            null  // The sort order
        )

        cursor?.use {
            if (it.moveToFirst()) {
                nombreUsuario = it.getString(it.getColumnIndexOrThrow(DatabaseContract.UserEntry.COLUMN_NAME_NOMBRE_USUARIO))
            }
        }

        cursor?.close() // Cerrar el cursor después de usarlo para liberar recursos
        db.close() // Cerrar la base de datos después de usarla para liberar recursos

        return nombreUsuario
    }
    }
