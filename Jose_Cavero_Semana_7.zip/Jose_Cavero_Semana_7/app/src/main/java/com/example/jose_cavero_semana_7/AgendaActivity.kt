package com.example.jose_cavero_semana_7


import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONArray
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

class AgendaActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: FeriadoAdapter
    private lateinit var textViewTitulo: TextView
    private lateinit var textViewUsuario: TextView
    private lateinit var btnCerrarSesion: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_agenda)

        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        adapter = FeriadoAdapter(mutableListOf())
        recyclerView.adapter = adapter

        textViewTitulo = findViewById(R.id.Titulo)
        textViewUsuario = findViewById(R.id.Usuario) // Cambiado a textViewUsuario
        btnCerrarSesion = findViewById(R.id.btnCerrarSesion)

        fetchFeriados()

        btnCerrarSesion.setOnClickListener {
            cerrarSesion()
        }
    }

    private fun fetchFeriados() {
        Thread {
            try {
                val url = URL("https://apis.digital.gob.cl/fl/feriados/2024")
                val urlConnection = url.openConnection() as HttpURLConnection
                try {
                    val reader = BufferedReader(InputStreamReader(urlConnection.inputStream))
                    val response = StringBuilder()
                    var line: String?
                    while (reader.readLine().also { line = it } != null) {
                        response.append(line)
                    }
                    reader.close()

                    runOnUiThread {

                        textViewTitulo.text = "Bienvenido" // Modificado
                        textViewUsuario.text = " ${obtenerNombreUsuario()}"
                        handleFeriadosResponse(response.toString())
                    }
                } finally {
                    urlConnection.disconnect()
                }
            } catch (e: Exception) {
                e.printStackTrace()

            }
        }.start()
    }

    private fun handleFeriadosResponse(response: String) {
        try {
            val jsonArray = JSONArray(response)
            val feriados = mutableListOf<Feriado>()
            for (i in 0 until jsonArray.length()) {
                val jsonObject = jsonArray.getJSONObject(i)
                val fecha = jsonObject.getString("fecha")
                val nombre = jsonObject.getString("nombre")
                val tipo = jsonObject.getString("tipo")
                feriados.add(Feriado(fecha, nombre, tipo))
            }
            adapter.actualizarFeriados(feriados)
        } catch (e: Exception) {
            e.printStackTrace()
            // Handle JSON response error
        }
    }

    private fun cerrarSesion() {
        SessionManager.setLoginStatus(this, false)
        val intent = Intent(this, LoginActivity::class.java)
        startActivity(intent)
        finish()
    }

    private fun obtenerNombreUsuario(): String {
        val dbHelper = DatabaseHelper(this)
        return dbHelper.obtenerNombreUsuario()
    }

}

